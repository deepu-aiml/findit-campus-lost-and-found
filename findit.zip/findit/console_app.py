"""Stages 1-5 - menu-driven console version of FindIt.

Run:  python console_app.py
"""
from datetime import date

import pandas as pd

import database as db
from matching import find_matches

pd.set_option("display.width", 200)
pd.set_option("display.max_colwidth", 40)

SHORT_COLS = ["id", "report_type", "item_name", "category", "location", "event_date", "status"]

MENU = """
==========  FindIt - Campus Lost & Found  ==========
 1. Report a lost item
 2. Report a found item
 3. View all reports
 4. Search items
 5. Smart match for a report
 6. Mark a report as resolved
 0. Exit
"""


def ask(prompt, required=True):
    while True:
        value = input(prompt).strip()
        if value or not required:
            return value
        print("  This field is required.")


def choose_category():
    for i, c in enumerate(db.CATEGORIES, 1):
        print(f"  {i:>2}. {c}")
    while True:
        pick = input("Category number: ").strip()
        if pick.isdigit() and 1 <= int(pick) <= len(db.CATEGORIES):
            return db.CATEGORIES[int(pick) - 1]
        print("  Enter a number from the list.")


def ask_date():
    while True:
        raw = input("Date (YYYY-MM-DD, Enter for today): ").strip()
        if not raw:
            return date.today().isoformat()
        try:
            return date.fromisoformat(raw).isoformat()
        except ValueError:
            print("  Use the format YYYY-MM-DD.")


def show(df):
    if df.empty:
        print("\n  Nothing found.")
    else:
        print("\n" + df[[c for c in SHORT_COLS if c in df.columns]].to_string(index=False))


def show_matches(report_id):
    report = db.get_report(report_id)
    if not report:
        print("  No report with that id.")
        return
    other = "found" if report["report_type"] == "lost" else "lost"
    matches = find_matches(report, db.get_reports(report_type=other, status="open"))
    if matches.empty:
        print("\n  No similar reports yet. We'll show matches as new reports arrive.")
        return
    print(f"\n  Possible matches for #{report['id']} ({report['item_name']}):")
    for _, m in matches.iterrows():
        print(f"   - #{m['id']} {m['item_name']} @ {m['location']}  "
              f"[{m['match_score']}% - {m['why']}]  contact: {m['contact_name']}, {m['contact_info']}")


def report_item(kind):
    verb = "lost" if kind == "lost" else "found"
    print(f"\n--- Report a {verb} item ---")
    name = ask("Item name: ")
    category = choose_category()
    location = ask(f"Where was it {verb}? ")
    when = ask_date()
    description = ask("Description (colour, brand, marks): ", required=False)
    contact_name = ask("Your name: ")
    contact_info = ask("Phone or email: ")
    rid = db.add_report(kind, name, category, location, description, when, contact_name, contact_info)
    print(f"\n  Saved as report #{rid}.")
    show_matches(rid)


def search():
    print("\n--- Search (leave blank to skip a filter) ---")
    keyword = ask("Item name / keyword: ", required=False)
    kind = ask("Type (lost / found / blank for both): ", required=False).lower() or None
    cat = ask("Category (exact name, blank for all): ", required=False) or None
    loc = ask("Location contains: ", required=False)
    show(db.get_reports(kind if kind in ("lost", "found") else None, cat, loc, keyword, "open"))


def main():
    db.init_db()
    actions = {
        "1": lambda: report_item("lost"),
        "2": lambda: report_item("found"),
        "3": lambda: show(db.get_reports()),
        "4": search,
        "5": lambda: show_matches(int(ask("Report id: "))),
        "6": lambda: (db.set_status(int(ask("Report id: ")), "resolved"), print("  Marked as resolved.")),
    }
    while True:
        print(MENU)
        choice = input("Choose an option: ").strip()
        if choice == "0":
            print("Goodbye!")
            break
        action = actions.get(choice)
        if not action:
            print("  Please choose 0-6.")
            continue
        try:
            action()
        except ValueError as err:
            print(f"  {err}")


if __name__ == "__main__":
    main()
