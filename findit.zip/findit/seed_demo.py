"""Fill the database with sample reports so the app has something to show.

Run:  python seed_demo.py
"""
from datetime import date, timedelta

import database as db

db.init_db()
d = lambda n: (date.today() - timedelta(days=n)).isoformat()

SAMPLES = [
    ("lost",  "Black Nike backpack", "Bags", "Central Library", "Black backpack, blue keychain on the zip, laptop charger inside", d(2), "Anil Kumar", "anil@campus.edu"),
    ("found", "Bag", "Bags", "Library 2nd floor", "Black bag with Nike logo and a blue keychain", d(1), "Sneha Rao", "98480 11122"),
    ("lost",  "AirPods case", "Electronics", "Canteen", "White earphone case with a small scratch", d(3), "Ravi Teja", "ravi@campus.edu"),
    ("found", "Student ID card", "ID & Cards", "Block C corridor", "ID card of a 2nd year CSE student", d(1), "Priya N", "priya@campus.edu"),
    ("lost",  "Hostel room keys", "Keys", "Sports ground", "Three keys on a red ring with a football tag", d(4), "Karthik S", "99890 22334"),
    ("found", "Keys with red ring", "Keys", "Near basketball court", "Bunch of 3 keys, red ring, small football charm", d(2), "Meena V", "meena@campus.edu"),
    ("lost",  "Steel water bottle", "Water Bottles", "Lab 3", "Blue steel flask with stickers", d(5), "Divya P", "divya@campus.edu"),
    ("found", "Scientific calculator", "Electronics", "Exam hall 2", "Casio fx-991 calculator", d(1), "Invigilator desk", "admin@campus.edu"),
]

if len(db.get_reports()) == 0:
    for s in SAMPLES:
        db.add_report(*s)
    print(f"Added {len(SAMPLES)} sample reports.")
else:
    print("Database already has reports; nothing added.")
