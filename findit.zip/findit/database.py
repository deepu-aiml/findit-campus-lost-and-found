"""Stage 3 - SQLite storage layer for FindIt.

Every other module (console app, Streamlit app, matching) goes through this
file, so the SQL lives in exactly one place.
"""
import os
import sqlite3
from contextlib import contextmanager
from datetime import datetime
from pathlib import Path

import pandas as pd

DB_PATH = Path(os.environ.get("FINDIT_DB", Path(__file__).with_name("findit.db")))

CATEGORIES = [
    "Electronics", "Bags", "Books & Stationery", "Clothing", "ID & Cards",
    "Keys", "Wallets & Money", "Water Bottles", "Jewellery", "Sports", "Other",
]

COLUMNS = [
    "id", "report_type", "item_name", "category", "location", "description",
    "event_date", "contact_name", "contact_info", "status", "created_at",
]


@contextmanager
def get_connection():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    try:
        yield conn
        conn.commit()
    finally:
        conn.close()


def init_db():
    with get_connection() as conn:
        conn.execute(
            """
            CREATE TABLE IF NOT EXISTS reports (
                id           INTEGER PRIMARY KEY AUTOINCREMENT,
                report_type  TEXT NOT NULL CHECK (report_type IN ('lost', 'found')),
                item_name    TEXT NOT NULL,
                category     TEXT NOT NULL,
                location     TEXT NOT NULL,
                description  TEXT DEFAULT '',
                event_date   TEXT NOT NULL,
                contact_name TEXT NOT NULL,
                contact_info TEXT NOT NULL,
                status       TEXT NOT NULL DEFAULT 'open'
                             CHECK (status IN ('open', 'resolved')),
                created_at   TEXT NOT NULL
            )
            """
        )
        conn.execute("CREATE INDEX IF NOT EXISTS idx_reports_type ON reports(report_type, status)")


def add_report(report_type, item_name, category, location, description,
               event_date, contact_name, contact_info):
    """Insert a report and return its new id. Raises ValueError on missing fields."""
    required = {"item name": item_name, "location": location,
                "contact name": contact_name, "contact info": contact_info}
    for label, value in required.items():
        if not str(value).strip():
            raise ValueError(f"Please fill in the {label}.")
    if report_type not in ("lost", "found"):
        raise ValueError("Report type must be 'lost' or 'found'.")

    with get_connection() as conn:
        cur = conn.execute(
            """INSERT INTO reports (report_type, item_name, category, location,
                                    description, event_date, contact_name,
                                    contact_info, created_at)
               VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)""",
            (report_type, item_name.strip(), category, location.strip(),
             (description or "").strip(), str(event_date), contact_name.strip(),
             contact_info.strip(), datetime.now().isoformat(timespec="seconds")),
        )
        return cur.lastrowid


def get_reports(report_type=None, category=None, location=None,
                keyword=None, status=None) -> pd.DataFrame:
    """Return reports as a DataFrame. All filters are optional and combine with AND."""
    sql, params = "SELECT * FROM reports WHERE 1=1", []
    if report_type:
        sql += " AND report_type = ?"
        params.append(report_type)
    if category and category != "All":
        sql += " AND category = ?"
        params.append(category)
    if location:
        sql += " AND location LIKE ?"
        params.append(f"%{location.strip()}%")
    if status:
        sql += " AND status = ?"
        params.append(status)
    if keyword:
        sql += " AND (item_name LIKE ? OR description LIKE ? OR category LIKE ? OR location LIKE ?)"
        params.extend([f"%{keyword.strip()}%"] * 4)
    sql += " ORDER BY created_at DESC, id DESC"

    with get_connection() as conn:
        df = pd.read_sql_query(sql, conn, params=params)
    return df if len(df) else pd.DataFrame(columns=COLUMNS)


def get_report(report_id):
    with get_connection() as conn:
        row = conn.execute("SELECT * FROM reports WHERE id = ?", (report_id,)).fetchone()
    return dict(row) if row else None


def set_status(report_id, status):
    with get_connection() as conn:
        conn.execute("UPDATE reports SET status = ? WHERE id = ?", (status, report_id))


def delete_report(report_id):
    with get_connection() as conn:
        conn.execute("DELETE FROM reports WHERE id = ?", (report_id,))


def stats() -> dict:
    df = get_reports()
    return {
        "open_lost": int(((df.report_type == "lost") & (df.status == "open")).sum()),
        "open_found": int(((df.report_type == "found") & (df.status == "open")).sum()),
        "resolved": int((df.status == "resolved").sum()),
        "total": len(df),
    }
