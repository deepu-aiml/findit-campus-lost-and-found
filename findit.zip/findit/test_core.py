"""Quick checks for the database and matching code.  Run: python test_core.py"""
import os
import tempfile

os.environ["FINDIT_DB"] = os.path.join(tempfile.mkdtemp(), "test.db")

import database as db
from matching import find_matches, all_matches, tokenize

db.init_db()
lost = db.add_report("lost", "Black Nike backpack", "Bags", "Central Library",
                     "black backpack, blue keychain", "2026-11-20", "A", "a@x.com")
found = db.add_report("found", "Bag", "Bags", "Library 2nd floor",
                      "Black bag with Nike logo and blue keychain", "2026-11-21", "B", "b@x.com")
db.add_report("found", "Scientific calculator", "Electronics", "Exam hall",
              "Casio calculator", "2026-11-21", "C", "c@x.com")
db.add_report("lost", "Steel bottle", "Water Bottles", "Lab 3", "blue flask", "2026-11-20", "D", "d@x.com")

assert tokenize("Keys on a red ring") == ["key", "red", "ring"]
assert len(db.get_reports()) == 4
assert len(db.get_reports(report_type="lost")) == 2
assert len(db.get_reports(location="library")) == 2
assert len(db.get_reports(category="Electronics")) == 1
assert len(db.get_reports(keyword="flask")) == 1

m = find_matches(db.get_report(lost), db.get_reports(report_type="found", status="open"))
assert not m.empty and m.iloc[0]["id"] == found, m
print("Top match:", m.iloc[0]["item_name"], f'{m.iloc[0]["match_score"]}%', "-", m.iloc[0]["why"])

pairs = all_matches(db.get_reports())
assert len(pairs) == 1, pairs        # the bottle and calculator must NOT pair up
db.set_status(found, "resolved")
assert all_matches(db.get_reports()).empty

try:
    db.add_report("lost", " ", "Other", "x", "", "2026-11-20", "n", "c")
    raise SystemExit("blank item name should have been rejected")
except ValueError:
    pass
print("All checks passed.")
