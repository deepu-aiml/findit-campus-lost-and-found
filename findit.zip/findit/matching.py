"""Stage 5 - Smart matching with basic text similarity (no external ML libraries).

Score (0-1) = weighted blend of
    45%  cosine similarity of the item name + description words
    25%  similarity of the item names
    15%  same category
    15%  similar location
"""
import difflib
import re
from collections import Counter
from math import sqrt

import pandas as pd

WEIGHTS = {"text": 0.45, "name": 0.25, "category": 0.15, "location": 0.15}

STOPWORDS = {
    "a", "an", "the", "and", "or", "of", "with", "in", "on", "at", "to", "my",
    "is", "it", "its", "was", "have", "had", "near", "from", "for", "i",
    "this", "that", "very", "some", "has", "inside", "found", "lost",
}

# Different words people use for the same thing.
SYNONYMS = {
    "bag": "backpack", "rucksack": "backpack", "bagpack": "backpack",
    "earphone": "headphone", "earbud": "headphone", "airpod": "headphone",
    "headset": "headphone", "mobile": "phone", "cellphone": "phone",
    "smartphone": "phone", "iphone": "phone", "purse": "wallet",
    "flask": "bottle", "tumbler": "bottle", "notebook": "book",
    "idcard": "id", "identity": "id", "laptop": "computer",
    "jacket": "coat", "hoodie": "sweater",
}


def tokenize(text) -> list:
    words = re.findall(r"[a-z0-9]+", str(text or "").lower())
    tokens = []
    for w in words:
        if len(w) > 3 and w.endswith("s") and not w.endswith("ss"):
            w = w[:-1]  # crude plural stripping: "keys" -> "key"
        w = SYNONYMS.get(w, w)
        if w not in STOPWORDS:
            tokens.append(w)
    return tokens


def cosine(a: list, b: list) -> float:
    ca, cb = Counter(a), Counter(b)
    if not ca or not cb:
        return 0.0
    dot = sum(ca[t] * cb[t] for t in ca)
    return dot / (sqrt(sum(v * v for v in ca.values())) * sqrt(sum(v * v for v in cb.values())))


def _text_ratio(a: str, b: str) -> float:
    ta, tb = tokenize(a), tokenize(b)
    if not ta or not tb:
        return 0.0
    seq = difflib.SequenceMatcher(None, " ".join(ta), " ".join(tb)).ratio()
    overlap = len(set(ta) & set(tb)) / len(set(ta) | set(tb))
    return max(seq, overlap)


def similarity(a, b):
    """Compare two reports (dict or Series). Returns (score 0-1, [reasons])."""
    text_a = f"{a['item_name']} {a['item_name']} {a.get('description', '')}"
    text_b = f"{b['item_name']} {b['item_name']} {b.get('description', '')}"
    parts = {
        "text": cosine(tokenize(text_a), tokenize(text_b)),
        "name": _text_ratio(a["item_name"], b["item_name"]),
        "category": 1.0 if a["category"] == b["category"] else 0.0,
        "location": _text_ratio(a["location"], b["location"]),
    }
    score = sum(WEIGHTS[k] * parts[k] for k in WEIGHTS)

    reasons = []
    if parts["name"] >= 0.5:
        reasons.append("similar item name")
    if parts["text"] >= 0.35:
        reasons.append("similar description")
    if parts["category"]:
        reasons.append("same category")
    if parts["location"] >= 0.5:
        reasons.append("similar location")
    return score, reasons


def find_matches(report, candidates: pd.DataFrame, min_score=0.35, top_n=5) -> pd.DataFrame:
    """Rank `candidates` (reports of the opposite type) against one report."""
    rows = []
    for _, cand in candidates.iterrows():
        if cand["report_type"] == report["report_type"] or cand["id"] == report.get("id"):
            continue
        score, reasons = similarity(report, cand)
        if score >= min_score:
            row = cand.to_dict()
            row["match_score"] = round(score * 100)
            row["why"] = ", ".join(reasons)
            rows.append(row)
    if not rows:
        return pd.DataFrame()
    return pd.DataFrame(rows).sort_values("match_score", ascending=False).head(top_n)


def all_matches(reports: pd.DataFrame, min_score=0.35) -> pd.DataFrame:
    """Every plausible lost/found pair among open reports (for the admin dashboard)."""
    open_reports = reports[reports["status"] == "open"]
    lost = open_reports[open_reports["report_type"] == "lost"]
    found = open_reports[open_reports["report_type"] == "found"]
    rows = []
    for _, l in lost.iterrows():
        for _, f in found.iterrows():
            score, reasons = similarity(l, f)
            if score >= min_score:
                rows.append({
                    "match_score": round(score * 100),
                    "lost_id": l["id"], "lost_item": l["item_name"], "lost_contact": l["contact_info"],
                    "found_id": f["id"], "found_item": f["item_name"], "found_contact": f["contact_info"],
                    "why": ", ".join(reasons),
                })
    cols = ["match_score", "lost_id", "lost_item", "lost_contact",
            "found_id", "found_item", "found_contact", "why"]
    df = pd.DataFrame(rows, columns=cols)
    return df.sort_values("match_score", ascending=False).reset_index(drop=True)
