# FindIt - Campus Lost & Found System

Students report lost items, report found items, and search the reports.
FindIt also compares descriptions to suggest which lost and found reports belong together.

## Setup

```bash
pip install -r requirements.txt
python seed_demo.py          # optional: adds sample reports
```

## Run

```bash
python console_app.py        # Stages 1-5: menu-driven console version
streamlit run app.py         # Stage 6: web app
python test_core.py          # checks for the database and matching code
```

Admin dashboard password: `admin123`. Change it with `FINDIT_ADMIN_PASSWORD=yourpassword streamlit run app.py`.

## Project structure

| File | Stage | Purpose |
|---|---|---|
| `database.py` | 3 | SQLite storage: add, filter, update, delete reports (`findit.db` is created on first run) |
| `console_app.py` | 1, 2, 4, 5 | Menu-driven console program |
| `matching.py` | 5 | Text-similarity matching (no extra libraries) |
| `app.py` | 6 | Streamlit pages: Home, Report Lost, Report Found, Search Items, Admin Dashboard |
| `seed_demo.py` | - | Sample data for demos |
| `test_core.py` | - | Automated checks |

## How smart matching works

Each lost/found pair gets a score from 0 to 100:

- 45% word overlap (cosine similarity) between item name + description
- 25% similarity of the item names
- 15% same category
- 15% similar location

Words are lower-cased, stop-words are dropped, plurals are trimmed, and common synonyms are merged
(bag = backpack, earbuds = headphones, flask = bottle). Pairs scoring 35 or more are shown as possible matches.
Tune `WEIGHTS`, `SYNONYMS` and `min_score` in `matching.py`.

## Ideas for next steps

- Email or SMS the owner when a likely match appears
- Photo upload for each report
- Student login so people can edit or close their own reports
