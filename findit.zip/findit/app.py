"""Stage 6 - Streamlit web app for FindIt.

Run:  streamlit run app.py
Admin password: set FINDIT_ADMIN_PASSWORD (default: admin123).
"""
import html
import os
from datetime import date

import pandas as pd
import streamlit as st

import database as db
from matching import all_matches, find_matches

st.set_page_config(page_title="FindIt - Campus Lost & Found", page_icon="🔎", layout="wide")
db.init_db()

ADMIN_PASSWORD = os.environ.get("FINDIT_ADMIN_PASSWORD", "admin123")
PAGES = ["Home", "Report Lost", "Report Found", "Search Items", "Admin Dashboard"]
LOST_COLOR, FOUND_COLOR = "#C2410C", "#0F6E6A"

st.markdown(
    """
    <style>
      .badge {display:inline-block; padding:2px 10px; border-radius:999px; color:#fff;
              font-size:0.8rem; font-weight:600; margin-right:8px;}
      .score {float:right; font-weight:600;}
      h1 {letter-spacing:-0.02em;}
    </style>
    """,
    unsafe_allow_html=True,
)

if "page" not in st.session_state:
    st.session_state.page = "Home"
if "admin" not in st.session_state:
    st.session_state.admin = False


def go(page):
    st.session_state.page = page


# ---------- shared pieces ----------
def report_card(row, score=None, why=None):
    kind = row["report_type"]
    color = LOST_COLOR if kind == "lost" else FOUND_COLOR
    with st.container(border=True):
        badge = f'<span class="badge" style="background:{color}">{kind.title()}</span>'
        score_html = f'<span class="score" style="color:{FOUND_COLOR}">{score}% match</span>' if score is not None else ""
        resolved = " (resolved)" if row["status"] == "resolved" else ""
        st.markdown(
            f"{badge}**{html.escape(row['item_name'])}**{resolved}{score_html}",
            unsafe_allow_html=True,
        )
        st.caption(f"{row['category']}  |  {row['location']}  |  {row['event_date']}")
        if row["description"]:
            st.text(row["description"])
        if why:
            st.caption(f"Why it matches: {why}")
        with st.expander("Contact"):
            st.write(f"{row['contact_name']} - {row['contact_info']}")


def show_cards(df):
    if df.empty:
        st.info("No reports match yet. Try fewer filters, or report the item so others can find it.")
        return
    for _, row in df.iterrows():
        report_card(row)


def show_matches_for(report_id):
    report = db.get_report(report_id)
    other = "found" if report["report_type"] == "lost" else "lost"
    matches = find_matches(report, db.get_reports(report_type=other, status="open"))
    if matches.empty:
        st.info("No similar reports yet. Check back soon: new reports are matched as they arrive.")
        return
    st.subheader("Possible matches")
    for _, m in matches.iterrows():
        report_card(m, score=m["match_score"], why=m["why"])


# ---------- pages ----------
def page_home():
    st.title("FindIt")
    st.write("Lost something on campus, or found something that isn't yours? Start here.")

    query = st.text_input("Search lost and found items", placeholder="e.g. backpack, keys, ID card, library")

    s = db.stats()
    c1, c2, c3 = st.columns(3)
    c1.metric("Items reported lost", s["open_lost"])
    c2.metric("Items waiting to be claimed", s["open_found"])
    c3.metric("Reunited with owners", s["resolved"])

    if query:
        results = db.get_reports(keyword=query, status="open")
        st.subheader(f"{len(results)} result(s) for '{query}'")
        show_cards(results)
        return

    b1, b2, _ = st.columns([1, 1, 3])
    b1.button("I lost something", on_click=go, args=("Report Lost",), type="primary")
    b2.button("I found something", on_click=go, args=("Report Found",))

    st.subheader("Latest reports")
    show_cards(db.get_reports(status="open").head(6))


def page_report(kind):
    lost = kind == "lost"
    st.title("Report a lost item" if lost else "Report a found item")
    st.write("Describe it as you would to a friend: colour, brand, stickers, anything unusual."
             if lost else "Tell us what you found and where it is now, so the owner can claim it.")

    with st.form(f"form_{kind}", clear_on_submit=True):
        name = st.text_input("Item name *", placeholder="e.g. Black backpack")
        c1, c2 = st.columns(2)
        category = c1.selectbox("Category *", db.CATEGORIES)
        location = c2.text_input("Where was it " + ("lost" if lost else "found") + "? *",
                                 placeholder="e.g. Central Library, 2nd floor")
        when = c1.date_input("Date", value=date.today(), max_value=date.today())
        description = st.text_area("Description", placeholder="Colour, brand, marks, what was inside...")
        c3, c4 = st.columns(2)
        contact_name = c3.text_input("Your name *")
        contact_info = c4.text_input("Phone or email *")
        submitted = st.form_submit_button("Submit report", type="primary")

    if submitted:
        try:
            rid = db.add_report(kind, name, category, location, description, when, contact_name, contact_info)
        except ValueError as err:
            st.error(str(err))
            return
        st.success(f"Report #{rid} saved.")
        show_matches_for(rid)


def page_search():
    st.title("Search items")
    c1, c2, c3, c4 = st.columns([2, 1, 1, 1.5])
    keyword = c1.text_input("Keyword", placeholder="item name or description")
    kind = c2.selectbox("Type", ["All", "Lost", "Found"])
    category = c3.selectbox("Category", ["All"] + db.CATEGORIES)
    location = c4.text_input("Location", placeholder="e.g. library")
    include_resolved = st.checkbox("Include resolved reports")

    df = db.get_reports(
        report_type=None if kind == "All" else kind.lower(),
        category=category, location=location, keyword=keyword,
        status=None if include_resolved else "open",
    )
    st.caption(f"{len(df)} report(s)")
    cards, table = st.tabs(["Cards", "Table"])
    with cards:
        show_cards(df)
    with table:
        st.dataframe(df.drop(columns=["contact_name", "contact_info"]), hide_index=True)


def page_admin():
    st.title("Admin dashboard")
    if not st.session_state.admin:
        with st.form("login"):
            pw = st.text_input("Admin password", type="password")
            if st.form_submit_button("Sign in", type="primary"):
                if pw == ADMIN_PASSWORD:
                    st.session_state.admin = True
                    st.rerun()
                else:
                    st.error("Wrong password.")
        return

    if st.button("Sign out"):
        st.session_state.admin = False
        st.rerun()

    df = db.get_reports()
    s = db.stats()
    m1, m2, m3, m4 = st.columns(4)
    m1.metric("Total reports", s["total"])
    m2.metric("Open lost", s["open_lost"])
    m3.metric("Open found", s["open_found"])
    m4.metric("Resolved", s["resolved"])

    manage, matches, analytics = st.tabs(["Manage reports", "Smart matches", "Analytics"])

    with manage:
        st.dataframe(df, hide_index=True)
        if not df.empty:
            labels = {int(r["id"]): f"#{r['id']}  {r['report_type']}  -  {r['item_name']}  ({r['status']})"
                      for _, r in df.iterrows()}
            chosen = int(st.selectbox("Select a report", list(labels), format_func=labels.get))
            b1, b2, b3, _ = st.columns([1, 1, 1, 3])
            if b1.button("Mark resolved"):
                db.set_status(chosen, "resolved")
                st.rerun()
            if b2.button("Reopen"):
                db.set_status(chosen, "open")
                st.rerun()
            if b3.button("Delete"):
                db.delete_report(chosen)
                st.rerun()
            st.download_button("Download all reports (CSV)", df.to_csv(index=False), "findit_reports.csv", "text/csv")

    with matches:
        pairs = all_matches(df)
        if pairs.empty:
            st.info("No open lost/found pairs look alike yet.")
        else:
            st.write("Open lost and found reports that look alike. Contact both people to arrange the hand-over.")
            st.dataframe(pairs, hide_index=True)

    with analytics:
        if df.empty:
            st.info("Charts appear once reports are added.")
        else:
            left, right = st.columns(2)
            left.write("Reports by category")
            left.bar_chart(df["category"].value_counts())
            right.write("Reports by location")
            right.bar_chart(df["location"].str.title().value_counts().head(8))
            st.write("Reports per day")
            per_day = df.groupby([df["created_at"].str[:10], "report_type"]).size().unstack(fill_value=0)
            st.line_chart(per_day)


# ---------- layout ----------
st.sidebar.title("FindIt")
st.sidebar.caption("Campus Lost & Found")
st.sidebar.radio("Go to", PAGES, key="page")

page = st.session_state.page
if page == "Home":
    page_home()
elif page == "Report Lost":
    page_report("lost")
elif page == "Report Found":
    page_report("found")
elif page == "Search Items":
    page_search()
else:
    page_admin()
